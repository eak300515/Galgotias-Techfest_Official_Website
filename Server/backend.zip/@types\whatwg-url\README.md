# Installation
> `npm install --save @types/whatwg-url`

# Summary
This package contains type definitions for whatwg-url (https://github.com/jsdom/whatwg-url#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/whatwg-url.

### Additional Details
 * Last updated: Sat, 18 May 2024 21:06:54 GMT
 * Dependencies: [@types/webidl-conversions](https://npmjs.com/package/@types/webidl-conversions)

# Credits
These definitions were written by [Alexander Marks](https://github.com/aomarks), [ExE Boss](https://github.com/ExE-Boss), and [BendingBender](https://github.com/BendingBender).
